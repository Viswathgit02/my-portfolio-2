const experiences = [
  {
    title: 'Data Analyst Intern',
    company: 'Tech Company XYZ',
    date: 'Summer 2023',
    description: 'Analyzed large datasets using Python and SQL to optimize system performance. Created insightful visualizations with Power BI.',
  },
  {
    title: 'IT Support Intern',
    company: 'Corporation ABC',
    date: 'Summer 2022',
    description: 'Provided technical support and implemented MS Office solutions to improve productivity across departments.',
  },
]

export default function Experience() {
  return (
    <section id="experience" className="py-20 bg-gray-100">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold mb-8 text-center">Internship Experience</h2>
        <div className="space-y-8">
          {experiences.map((exp, index) => (
            <div key={index} className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-2">{exp.title}</h3>
              <p className="text-gray-600 mb-2">{exp.company} | {exp.date}</p>
              <p className="text-gray-700">{exp.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

