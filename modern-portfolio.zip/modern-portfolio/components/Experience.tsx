import { Briefcase, Calendar, MapPin } from 'lucide-react'

const experiences = [
  {
    title: 'Full Stack Intern',
    company: 'Datapro',
    location: 'Anakapalli, India',
    duration: '45 days internship',
    description: [
      'Performed system analysis to identify areas for improvement in performance and scalability',
      'Optimized application performance by reducing response times and memory usage',
      'Performed customer-focused design analysis resulting in implementation of user-driven changes',
      'Identified solutions for improvement',
    ],
  },
  {
    title: 'Data Visualisation',
    company: 'TATA',
    location: 'Virtual, India',
    duration: 'November 2024',
    description: [
      'Developed Business Scenario',
      'Selected the Right Visuals',
      'Created Visuals for the Clients',
      'Analyzed Insights and Analysis',
    ],
  },
]

export default function Experience() {
  return (
    <section id="experience" className="py-24 bg-black bg-opacity-80">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold mb-16 text-center text-accent-green">Work Experience</h2>
        <div className="space-y-12">
          {experiences.map((exp, index) => (
            <div key={index} className="bg-gray-900 p-8 rounded-lg shadow-md border border-accent-blue">
              <div className="flex flex-col md:flex-row md:items-center mb-6">
                <div className="flex-1">
                  <h3 className="text-2xl font-semibold text-accent-blue mb-2">{exp.title}</h3>
                  <p className="text-xl text-white mb-2">{exp.company}</p>
                </div>
                <div className="flex flex-col md:items-end mt-4 md:mt-0">
                  <p className="text-gray-300 flex items-center mb-2">
                    <MapPin className="h-5 w-5 mr-2 text-accent-green" />
                    {exp.location}
                  </p>
                  <p className="text-gray-300 flex items-center">
                    <Calendar className="h-5 w-5 mr-2 text-accent-green" />
                    {exp.duration}
                  </p>
                </div>
              </div>
              <ul className="list-disc list-inside text-gray-300 space-y-2">
                {exp.description.map((item, i) => (
                  <li key={i} className="ml-4">{item}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

