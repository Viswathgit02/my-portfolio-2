const experiences = [
  {
    title: 'Full Stack Intern',
    company: 'Datapro',
    location: 'Anakapalli, India',
    duration: '45 days internship',
    description: [
      'Performed system analysis to identify areas for improvement in performance and scalability',
      'Optimized application performance by reducing response times and memory usage',
      'Performed customer-focused design analysis resulting in implementation of user-driven changes',
      'Identified solutions for improvement',
    ],
  },
  {
    title: 'Data Visualisation',
    company: 'TATA',
    location: 'Virtual, India',
    duration: 'November 2024',
    description: [
      'Developed Business Scenario',
      'Selected the Right Visuals',
      'Created Visuals for the Clients',
      'Analyzed Insights and Analysis',
    ],
  },
]

export default function Experience() {
  return (
    <section id="experience" className="py-20 bg-gray-100">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold mb-8 text-center">Work Experience</h2>
        <div className="space-y-8">
          {experiences.map((exp, index) => (
            <div key={index} className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-2">{exp.title}</h3>
              <p className="text-gray-600 mb-2">{exp.company} | {exp.location}</p>
              <p className="text-gray-600 mb-4">{exp.duration}</p>
              <ul className="list-disc list-inside text-gray-700">
                {exp.description.map((item, i) => (
                  <li key={i}>{item}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

