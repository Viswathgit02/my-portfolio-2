import { Briefcase, Calendar, MapPin } from 'lucide-react'

const experiences = [
  {
    title: 'Full Stack Intern',
    company: 'Datapro',
    location: 'Anakapalli, India',
    duration: '45 days internship',
    description: [
      'Performed system analysis to identify areas for improvement in performance and scalability',
      'Optimized application performance by reducing response times and memory usage',
      'Performed customer-focused design analysis resulting in implementation of user-driven changes',
      'Identified solutions for improvement',
    ],
  },
  {
    title: 'Data Visualisation',
    company: 'TATA',
    location: 'Virtual, India',
    duration: 'November 2024',
    description: [
      'Developed Business Scenario',
      'Selected the Right Visuals',
      'Created Visuals for the Clients',
      'Analyzed Insights and Analysis',
    ],
  },
]

export default function Experience() {
  return (
    <section id="experience" className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold mb-10 text-center text-gray-800">Work Experience</h2>
        <div className="space-y-8">
          {experiences.map((exp, index) => (
            <div key={index} className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex flex-col md:flex-row md:items-center mb-4">
                <div className="flex-1">
                  <h3 className="text-xl font-semibold text-blue-600 mb-1">{exp.title}</h3>
                  <p className="text-lg text-gray-700 mb-1">{exp.company}</p>
                </div>
                <div className="flex flex-col md:items-end mt-2 md:mt-0">
                  <p className="text-sm text-gray-600 flex items-center mb-1">
                    <MapPin className="h-4 w-4 mr-1" />
                    {exp.location}
                  </p>
                  <p className="text-sm text-gray-600 flex items-center">
                    <Calendar className="h-4 w-4 mr-1" />
                    {exp.duration}
                  </p>
                </div>
              </div>
              <ul className="list-disc list-inside text-gray-700 text-sm space-y-1">
                {exp.description.map((item, i) => (
                  <li key={i} className="ml-2">{item}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

