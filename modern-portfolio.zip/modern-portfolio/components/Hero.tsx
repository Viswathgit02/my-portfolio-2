import { ArrowRight } from 'lucide-react'

export default function Hero() {
  return (
    <section className="bg-gradient-to-r from-blue-500 to-purple-600 text-white py-20">
      <div className="container mx-auto px-4">
        <h1 className="text-4xl md:text-6xl font-bold mb-4">Viswath Ravinoothala</h1>
        <p className="text-xl md:text-2xl mb-8">Computer Science Graduate | Python | SQL | Power BI | MS Office</p>
        <p className="text-lg mb-8">Motivated and adaptable computer science graduate with hands-on experience in system analysis and code optimization. Seeking an entry-level role to leverage technical and project management skills.</p>
        <a href="#contact" className="inline-flex items-center bg-white text-blue-600 font-bold py-3 px-6 rounded-full hover:bg-blue-100 transition duration-300">
          Get in touch
          <ArrowRight className="ml-2 h-5 w-5" />
        </a>
      </div>
    </section>
  )
}

