import { ArrowRight, Mail, Linkedin } from 'lucide-react'

export default function Hero() {
  return (
    <section className="bg-gradient-to-r from-blue-500 to-purple-600 text-white py-20">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-4">Viswath Ravinoothala</h1>
          <p className="text-xl md:text-2xl mb-6">Computer Science Graduate | Python | SQL | Power BI | MS Office</p>
          <p className="text-lg mb-8">Motivated and adaptable computer science graduate with hands-on experience in system analysis and code optimization. Seeking an entry-level role to leverage technical and project management skills.</p>
          <div className="flex justify-center space-x-4">
            <a href="mailto:viswathravinoothala@gmail.com" className="inline-flex items-center bg-white text-blue-600 font-bold py-2 px-4 rounded-full hover:bg-blue-100 transition duration-300">
              <Mail className="mr-2 h-5 w-5" />
              Contact Me
            </a>
            <a href="https://linkedin.com/in/viswath-ravinoothala-09601a327" target="_blank" rel="noopener noreferrer" className="inline-flex items-center bg-blue-700 text-white font-bold py-2 px-4 rounded-full hover:bg-blue-800 transition duration-300">
              <Linkedin className="mr-2 h-5 w-5" />
              LinkedIn
            </a>
          </div>
        </div>
      </div>
    </section>
  )
}

