import { ArrowRight, Mail, Linkedin } from 'lucide-react'
import Link from 'next/link'

export default function Hero() {
  return (
    <section className="bg-gradient-to-r from-blue-600 to-purple-600 text-white py-24">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6 animate-fade-in">Viswath Ravinoothala</h1>
          <p className="text-xl md:text-2xl mb-8 animate-fade-in delay-100">Computer Science Graduate | Python | SQL | Power BI | MS Office</p>
          <p className="text-lg mb-10 animate-fade-in delay-200">Motivated and adaptable computer science graduate with hands-on experience in system analysis and code optimization. Seeking an entry-level role to leverage technical and project management skills.</p>
          <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4 animate-fade-in delay-300">
            <a 
              href="#contact" 
              className="inline-flex items-center bg-white text-blue-600 font-bold py-3 px-6 rounded-full hover:bg-blue-100 transition duration-300"
              onClick={(e) => {
                e.preventDefault();
                document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
              }}
            >
              <Mail className="mr-2 h-5 w-5" />
              Contact Me
            </a>
            <a href="https://linkedin.com/in/viswath-ravinoothala-09601a327" target="_blank" rel="noopener noreferrer" className="inline-flex items-center bg-blue-700 text-white font-bold py-3 px-6 rounded-full hover:bg-blue-800 transition duration-300">
              <Linkedin className="mr-2 h-5 w-5" />
              LinkedIn
            </a>
          </div>
        </div>
      </div>
    </section>
  )
}

