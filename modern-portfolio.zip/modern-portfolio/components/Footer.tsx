import { Github, Linkedin, Mail } from 'lucide-react'

export default function Footer() {
  return (
    <footer className="bg-gray-800 text-white py-8">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <p className="mb-4 md:mb-0">&copy; 2023 Viswath Ravinoothala. All rights reserved.</p>
          <div className="flex space-x-4">
            <a href="https://linkedin.com/in/viswath-ravinoothala-09601a327" target="_blank" rel="noopener noreferrer" className="hover:text-blue-400">
              <Linkedin className="h-6 w-6" />
            </a>
            <a href="mailto:viswathravinoothala@gmail.com" className="hover:text-blue-400">
              <Mail className="h-6 w-6" />
            </a>
          </div>
        </div>
        <div className="mt-4 text-center">
          <p>Phone: +91 9948181520</p>
          <p>Interests: Reading, Exploring Cuisines, Cooking, Music</p>
          <p>Languages: Telugu, English</p>
        </div>
      </div>
    </footer>
  )
}

