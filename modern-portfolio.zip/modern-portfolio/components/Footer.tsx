import { Mail, Phone, MapPin, Book, Music, Coffee } from 'lucide-react'

export default function Footer() {
  return (
    <footer className="bg-gray-800 text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-8">
          <div>
            <h3 className="text-2xl font-semibold mb-4">Contact Information</h3>
            <ul className="space-y-2">
              <li className="flex items-center">
                <Mail className="h-5 w-5 mr-2" />
                <a href="mailto:viswathravinoothala@gmail.com" className="hover:text-blue-400">viswathravinoothala@gmail.com</a>
              </li>
              <li className="flex items-center">
                <Phone className="h-5 w-5 mr-2" />
                <a href="tel:+919948181520" className="hover:text-blue-400">+91 9948181520</a>
              </li>
              <li className="flex items-center">
                <MapPin className="h-5 w-5 mr-2" />
                <span>Anakapalli, India</span>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="text-2xl font-semibold mb-4">Interests & Languages</h3>
            <ul className="space-y-2">
              <li className="flex items-center">
                <Book className="h-5 w-5 mr-2" />
                <span>Reading</span>
              </li>
              <li className="flex items-center">
                <Coffee className="h-5 w-5 mr-2" />
                <span>Exploring Cuisines</span>
              </li>
              <li className="flex items-center">
                <Music className="h-5 w-5 mr-2" />
                <span>Music</span>
              </li>
              <li className="mt-4">
                <strong>Languages:</strong> Telugu, English
              </li>
            </ul>
          </div>
        </div>
        <div className="mt-8 text-center">
          <p>&copy; 2023 Viswath Ravinoothala. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}

