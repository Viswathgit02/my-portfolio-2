import { Mail, Phone, MapPin, Book, Music, Coffee, Linkedin } from 'lucide-react'

export default function Footer() {
  return (
    <footer id="contact" className="bg-gray-800 text-white py-16">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-12">
          <div>
            <h3 className="text-2xl font-semibold mb-6">Contact Information</h3>
            <ul className="space-y-4">
              <li className="flex items-center">
                <Mail className="h-6 w-6 mr-4 text-blue-400" />
                <a href="mailto:viswathravinoothala@gmail.com" className="hover:text-blue-400 transition-colors">viswathravinoothala@gmail.com</a>
              </li>
              <li className="flex items-center">
                <Phone className="h-6 w-6 mr-4 text-blue-400" />
                <a href="tel:+919948181520" className="hover:text-blue-400 transition-colors">+91 9948181520</a>
              </li>
              <li className="flex items-center">
                <MapPin className="h-6 w-6 mr-4 text-blue-400" />
                <span>Anakapalli, India</span>
              </li>
              <li className="flex items-center">
                <Linkedin className="h-6 w-6 mr-4 text-blue-400" />
                <a href="https://linkedin.com/in/viswath-ravinoothala-09601a327" target="_blank" rel="noopener noreferrer" className="hover:text-blue-400 transition-colors">linkedin.com/in/viswath-ravinoothala-09601a327</a>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="text-2xl font-semibold mb-6">Interests & Languages</h3>
            <ul className="space-y-4">
              <li className="flex items-center">
                <Book className="h-6 w-6 mr-4 text-blue-400" />
                <span>Reading</span>
              </li>
              <li className="flex items-center">
                <Coffee className="h-6 w-6 mr-4 text-blue-400" />
                <span>Exploring Cuisines</span>
              </li>
              <li className="flex items-center">
                <Music className="h-6 w-6 mr-4 text-blue-400" />
                <span>Music</span>
              </li>
              <li className="mt-6">
                <strong className="text-blue-400">Languages:</strong> Telugu, English
              </li>
            </ul>
          </div>
        </div>
        <div className="mt-12 pt-8 border-t border-gray-700 text-center">
          <p>&copy; 2023 Viswath Ravinoothala. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}

