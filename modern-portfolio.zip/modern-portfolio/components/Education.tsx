export default function Education() {
  return (
    <section id="education" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold mb-8 text-center">Educational Background</h2>
        <div className="bg-gray-100 p-6 rounded-lg">
          <h3 className="text-xl font-semibold mb-2">Bachelor of Science in Computer Science</h3>
          <p className="text-gray-600 mb-2">University Name</p>
          <p className="text-gray-700">Expected Graduation: May 2024</p>
          <p className="text-gray-700 mt-4">Relevant Coursework: Data Structures, Algorithms, Database Systems, Data Analysis</p>
        </div>
      </div>
    </section>
  )
}

