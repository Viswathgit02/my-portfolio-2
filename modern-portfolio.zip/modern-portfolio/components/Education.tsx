const educationData = [
  {
    degree: "Bachelor's in Computer Science",
    institution: "Dadi Veerunaidu degree College",
    location: "Anakapalli, India",
    date: "May 2024",
    grade: "7.22",
  },
  {
    degree: "Intermediate in MPC",
    institution: "Narayana Junior College",
    location: "Anakapalli, India",
    date: "July 2020",
    grade: "6.5",
  },
  {
    degree: "X in SSC",
    institution: "Narayana High Schools",
    location: "Anakapalli, India",
    date: "April 2018",
    grade: "8.5",
  },
]

export default function Education() {
  return (
    <section id="education" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold mb-8 text-center">Educational Background</h2>
        <div className="space-y-6">
          {educationData.map((edu, index) => (
            <div key={index} className="bg-gray-100 p-6 rounded-lg">
              <h3 className="text-xl font-semibold mb-2">{edu.degree}</h3>
              <p className="text-gray-600 mb-2">{edu.institution}, {edu.location}</p>
              <p className="text-gray-700">Graduation: {edu.date}</p>
              <p className="text-gray-700">Grade: {edu.grade}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

