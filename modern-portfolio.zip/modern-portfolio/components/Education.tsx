import { GraduationCap, Calendar, Star, MapPin } from 'lucide-react'

const educationData = [
  {
    degree: "Bachelor's in Computer Science",
    institution: "Dadi Veerunaidu degree College",
    location: "Anakapalli, India",
    date: "May 2024",
    grade: "7.22",
  },
  {
    degree: "Intermediate in MPC",
    institution: "Narayana Junior College",
    location: "Anakapalli, India",
    date: "July 2020",
    grade: "6.5",
  },
  {
    degree: "X in SSC",
    institution: "Narayana High Schools",
    location: "Anakapalli, India",
    date: "April 2018",
    grade: "8.5",
  },
]

export default function Education() {
  return (
    <section id="education" className="py-24 bg-gray-50">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold mb-16 text-center text-gray-800">Educational Background</h2>
        <div className="space-y-12">
          {educationData.map((edu, index) => (
            <div key={index} className="bg-white p-8 rounded-lg shadow-md hover:shadow-lg transition-shadow">
              <div className="flex flex-col md:flex-row md:items-center">
                <div className="flex-1">
                  <h3 className="text-2xl font-semibold text-blue-600 mb-2">{edu.degree}</h3>
                  <p className="text-xl text-gray-700 mb-2">{edu.institution}</p>
                </div>
                <div className="flex flex-col md:items-end mt-4 md:mt-0">
                  <p className="text-gray-600 flex items-center mb-2">
                    <MapPin className="h-5 w-5 mr-2" />
                    {edu.location}
                  </p>
                  <p className="text-gray-600 flex items-center mb-2">
                    <Calendar className="h-5 w-5 mr-2" />
                    {edu.date}
                  </p>
                  <p className="text-gray-700 flex items-center">
                    <Star className="h-5 w-5 mr-2 text-yellow-500" />
                    Grade: {edu.grade}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

