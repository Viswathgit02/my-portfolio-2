import { GraduationCap, Calendar, Star } from 'lucide-react'

const educationData = [
  {
    degree: "Bachelor's in Computer Science",
    institution: "Dadi Veerunaidu degree College",
    location: "Anakapalli, India",
    date: "May 2024",
    grade: "7.22",
  },
  {
    degree: "Intermediate in MPC",
    institution: "Narayana Junior College",
    location: "Anakapalli, India",
    date: "July 2020",
    grade: "6.5",
  },
  {
    degree: "X in SSC",
    institution: "Narayana High Schools",
    location: "Anakapalli, India",
    date: "April 2018",
    grade: "8.5",
  },
]

export default function Education() {
  return (
    <section id="education" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold mb-12 text-center">Educational Background</h2>
        <div className="space-y-8">
          {educationData.map((edu, index) => (
            <div key={index} className="bg-gray-50 p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
              <div className="flex items-center mb-4">
                <GraduationCap className="h-6 w-6 text-blue-500 mr-2" />
                <h3 className="text-xl font-semibold">{edu.degree}</h3>
              </div>
              <p className="text-gray-600 mb-2">{edu.institution}, {edu.location}</p>
              <p className="text-gray-600 mb-2 flex items-center">
                <Calendar className="h-4 w-4 mr-2" />
                {edu.date}
              </p>
              <p className="text-gray-700 flex items-center">
                <Star className="h-4 w-4 mr-2 text-yellow-500" />
                Grade: {edu.grade}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

