// ... (previous imports and constants remain the same)

export default function Education() {
  return (
    <section id="education" className="py-24 bg-white bg-opacity-80">
      {/* ... (rest of the component remains the same) */}
    </section>
  )
}

