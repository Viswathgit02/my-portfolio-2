import { Award, Calendar } from 'lucide-react'

const certifications = [
  {
    name: "AWS Cloud Foundation",
    issuer: "AWS",
    date: "September 11, 2022",
    description: "AWS Cloud Virtual Internship in partnership with AWS Academy",
  },
  {
    name: "Data Visualisation",
    issuer: "TATA",
    date: "November 19, 2024",
    description: "Empowering Business with Effective Insights for Data Visualization",
  },
]

const awards = [
  {
    name: "Silver medal",
    issuer: "NSO",
    date: "October 25, 2017",
    description: "Awarded for excellence in successfully navigating competitive exams",
  },
]

export default function Certifications() {
  return (
    <section id="certifications" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold mb-12 text-center">Certifications & Awards</h2>
        <div className="grid md:grid-cols-2 gap-8">
          <div>
            <h3 className="text-2xl font-semibold mb-6">Certifications</h3>
            {certifications.map((cert, index) => (
              <div key={index} className="bg-white p-6 rounded-lg shadow-md mb-6 hover:shadow-lg transition-shadow">
                <div className="flex items-center mb-4">
                  <Award className="h-6 w-6 text-blue-500 mr-2" />
                  <h4 className="text-xl font-semibold">{cert.name}</h4>
                </div>
                <p className="text-gray-600 mb-2">{cert.issuer}</p>
                <p className="text-gray-600 mb-2 flex items-center">
                  <Calendar className="h-4 w-4 mr-2" />
                  {cert.date}
                </p>
                <p className="text-gray-700">{cert.description}</p>
              </div>
            ))}
          </div>
          <div>
            <h3 className="text-2xl font-semibold mb-6">Awards</h3>
            {awards.map((award, index) => (
              <div key={index} className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
                <div className="flex items-center mb-4">
                  <Award className="h-6 w-6 text-yellow-500 mr-2" />
                  <h4 className="text-xl font-semibold">{award.name}</h4>
                </div>
                <p className="text-gray-600 mb-2">{award.issuer}</p>
                <p className="text-gray-600 mb-2 flex items-center">
                  <Calendar className="h-4 w-4 mr-2" />
                  {award.date}
                </p>
                <p className="text-gray-700">{award.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

