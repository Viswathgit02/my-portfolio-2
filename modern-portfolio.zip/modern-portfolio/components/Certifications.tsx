const certifications = [
  {
    name: "AWS Cloud Foundation",
    issuer: "AWS",
    date: "September 11, 2022",
    description: "AWS Cloud Virtual Internship in partnership with AWS Academy",
  },
  {
    name: "Data Visualisation",
    issuer: "TATA",
    date: "November 19, 2024",
    description: "Empowering Business with Effective Insights for Data Visualization",
  },
]

export default function Certifications() {
  return (
    <section id="certifications" className="py-20 bg-gray-100">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold mb-8 text-center">Certifications</h2>
        <div className="grid md:grid-cols-2 gap-6">
          {certifications.map((cert, index) => (
            <div key={index} className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-2">{cert.name}</h3>
              <p className="text-gray-600 mb-2">{cert.issuer} | {cert.date}</p>
              <p className="text-gray-700">{cert.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

