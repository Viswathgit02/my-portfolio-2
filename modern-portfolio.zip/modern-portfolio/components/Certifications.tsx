// ... (previous imports and constants remain the same)

export default function Certifications() {
  return (
    <section id="certifications" className="py-24 bg-gray-50 bg-opacity-80">
      {/* ... (rest of the component remains the same) */}
    </section>
  )
}

