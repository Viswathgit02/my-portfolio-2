"use client"

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { Menu, X } from 'lucide-react'

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isScrolled, setIsScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10)
    }

    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isScrolled ? 'bg-black bg-opacity-80 backdrop-blur-sm' : 'bg-transparent'}`}>
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <Link href="/" className="text-2xl font-bold text-accent-green">VR</Link>
        <nav className={`${isMenuOpen ? 'block' : 'hidden'} md:block absolute md:relative top-full left-0 w-full md:w-auto bg-black md:bg-transparent ${isScrolled ? 'bg-opacity-80 backdrop-blur-sm' : 'bg-opacity-90'} md:bg-opacity-0 md:backdrop-blur-none`}>
          <ul className="flex flex-col md:flex-row space-y-4 md:space-y-0 md:space-x-6 p-4 md:p-0">
            <li><Link href="#skills" className="text-white hover:text-accent-green transition-colors" onClick={() => setIsMenuOpen(false)}>Skills</Link></li>
            <li><Link href="#experience" className="text-white hover:text-accent-green transition-colors" onClick={() => setIsMenuOpen(false)}>Experience</Link></li>
            <li><Link href="#education" className="text-white hover:text-accent-green transition-colors" onClick={() => setIsMenuOpen(false)}>Education</Link></li>
            <li><Link href="#certifications" className="text-white hover:text-accent-green transition-colors" onClick={() => setIsMenuOpen(false)}>Certifications</Link></li>
            <li><Link href="#contact" className="text-white hover:text-accent-green transition-colors" onClick={() => setIsMenuOpen(false)}>Contact</Link></li>
          </ul>
        </nav>
        <button className="md:hidden text-white hover:text-accent-green transition-colors" onClick={() => setIsMenuOpen(!isMenuOpen)}>
          {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>
    </header>
  )
}

