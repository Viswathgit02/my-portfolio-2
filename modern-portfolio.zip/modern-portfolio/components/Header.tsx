"use client"

import { useState } from 'react'
import Link from 'next/link'
import { Menu, X } from 'lucide-react'

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <header className="bg-white shadow-md sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <Link href="/" className="text-2xl font-bold text-blue-600">VR</Link>
        <nav className={`${isMenuOpen ? 'block' : 'hidden'} md:block absolute md:relative top-full left-0 w-full md:w-auto bg-white md:bg-transparent shadow-md md:shadow-none`}>
          <ul className="flex flex-col md:flex-row space-y-2 md:space-y-0 md:space-x-6 p-4 md:p-0">
            <li><Link href="#skills" className="text-gray-700 hover:text-blue-600" onClick={() => setIsMenuOpen(false)}>Skills</Link></li>
            <li><Link href="#experience" className="text-gray-700 hover:text-blue-600" onClick={() => setIsMenuOpen(false)}>Experience</Link></li>
            <li><Link href="#education" className="text-gray-700 hover:text-blue-600" onClick={() => setIsMenuOpen(false)}>Education</Link></li>
            <li><Link href="#certifications" className="text-gray-700 hover:text-blue-600" onClick={() => setIsMenuOpen(false)}>Certifications</Link></li>
          </ul>
        </nav>
        <button className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
          {isMenuOpen ? <X className="h-6 w-6 text-gray-600" /> : <Menu className="h-6 w-6 text-gray-600" />}
        </button>
      </div>
    </header>
  )
}

