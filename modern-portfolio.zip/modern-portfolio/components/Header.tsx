import Link from 'next/link'
import { Menu } from 'lucide-react'

export default function Header() {
  return (
    <header className="bg-white shadow-md">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <Link href="/" className="text-2xl font-bold text-gray-800">Viswath Ravinoothala</Link>
        <nav className="hidden md:flex space-x-4">
          <Link href="#skills" className="text-gray-600 hover:text-gray-800">Skills</Link>
          <Link href="#experience" className="text-gray-600 hover:text-gray-800">Experience</Link>
          <Link href="#education" className="text-gray-600 hover:text-gray-800">Education</Link>
          <Link href="#certifications" className="text-gray-600 hover:text-gray-800">Certifications</Link>
        </nav>
        <button className="md:hidden">
          <Menu className="h-6 w-6 text-gray-600" />
        </button>
      </div>
    </header>
  )
}

