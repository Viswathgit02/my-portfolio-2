import { Code, Database, BarChart, FileSpreadsheet, MessageSquare, Clock, Users, BrainCircuit } from 'lucide-react'

const technicalSkills = [
  { name: 'Python', icon: Code, level: 'Advanced' },
  { name: 'SQL', icon: Database, level: 'Proficient' },
  { name: 'Power BI', icon: BarChart, level: 'Intermediate' },
  { name: 'MS Office', icon: FileSpreadsheet, level: 'Advanced' },
]

const softSkills = [
  'Excellent Communication',
  'Fast Learner',
  'Team Player',
  'Problem Solving',
  'Adaptability',
  'Time Management',
]

export default function Skills() {
  return (
    <section id="skills" className="py-24 bg-gray-50">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold mb-16 text-center text-gray-800">Skills & Expertise</h2>
        <div className="grid md:grid-cols-2 gap-16">
          <div>
            <h3 className="text-2xl font-semibold mb-8 text-center text-blue-600">Technical Skills</h3>
            <div className="space-y-6">
              {technicalSkills.map((skill) => (
                <div key={skill.name} className="bg-white p-6 rounded-lg shadow-md">
                  <div className="flex items-center mb-4">
                    <skill.icon className="h-8 w-8 text-blue-500 mr-4" />
                    <h4 className="text-xl font-semibold">{skill.name}</h4>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2.5">
                    <div 
                      className="bg-blue-600 h-2.5 rounded-full" 
                      style={{ width: skill.level === 'Advanced' ? '90%' : skill.level === 'Proficient' ? '75%' : '60%' }}
                    ></div>
                  </div>
                  <p className="text-right mt-2 text-sm text-gray-600">{skill.level}</p>
                </div>
              ))}
            </div>
          </div>
          <div>
            <h3 className="text-2xl font-semibold mb-8 text-center text-blue-600">Soft Skills</h3>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <ul className="grid grid-cols-2 gap-4">
                {softSkills.map((skill, index) => (
                  <li key={index} className="flex items-center">
                    <BrainCircuit className="h-5 w-5 text-blue-500 mr-2" />
                    <span>{skill}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

