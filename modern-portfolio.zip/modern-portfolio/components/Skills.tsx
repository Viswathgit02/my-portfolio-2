import { Code, Database, BarChart, FileSpreadsheet, MessageSquare, Clock, Users, BrainCircuit } from 'lucide-react'

const technicalSkills = [
  { name: 'Python', icon: Code },
  { name: 'SQL', icon: Database },
  { name: 'Power BI', icon: BarChart },
  { name: 'MS Office', icon: FileSpreadsheet },
]

const softSkills = [
  { name: 'Communication', icon: MessageSquare },
  { name: 'Fast Learner', icon: Clock },
  { name: 'Team Work', icon: Users },
  { name: 'Problem Solving', icon: BrainCircuit },
]

export default function Skills() {
  return (
    <section id="skills" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold mb-12 text-center">Skills</h2>
        <div className="grid md:grid-cols-2 gap-12">
          <div>
            <h3 className="text-2xl font-semibold mb-6 text-center">Technical Skills</h3>
            <div className="grid grid-cols-2 gap-8">
              {technicalSkills.map((skill) => (
                <div key={skill.name} className="flex flex-col items-center bg-gray-50 p-6 rounded-lg shadow-md transition-transform hover:scale-105">
                  <skill.icon className="h-12 w-12 text-blue-500 mb-4" />
                  <h4 className="text-lg font-semibold">{skill.name}</h4>
                </div>
              ))}
            </div>
          </div>
          <div>
            <h3 className="text-2xl font-semibold mb-6 text-center">Soft Skills</h3>
            <div className="grid grid-cols-2 gap-8">
              {softSkills.map((skill) => (
                <div key={skill.name} className="flex flex-col items-center bg-gray-50 p-6 rounded-lg shadow-md transition-transform hover:scale-105">
                  <skill.icon className="h-12 w-12 text-blue-500 mb-4" />
                  <h4 className="text-lg font-semibold">{skill.name}</h4>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

