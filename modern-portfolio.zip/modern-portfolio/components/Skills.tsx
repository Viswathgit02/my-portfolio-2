import { Code, Database, BarChart, FileSpreadsheet, MessageSquare, Clock, Users, BrainCircuit } from 'lucide-react'

const technicalSkills = [
  { name: 'Python', icon: Code, description: 'Proficient in data analysis and automation' },
  { name: 'SQL', icon: Database, description: 'Experienced in database management and querying' },
  { name: 'Power BI', icon: BarChart, description: 'Skilled in creating interactive dashboards' },
  { name: 'MS Office', icon: FileSpreadsheet, description: 'Advanced user of Excel, Word, and PowerPoint' },
]

const softSkills = [
  { name: 'Communication', icon: MessageSquare, description: 'Excellent verbal and written skills' },
  { name: 'Fast Learner', icon: Clock, description: 'Quick to adapt to new technologies' },
  { name: 'Team Work', icon: Users, description: 'Collaborative and supportive team player' },
  { name: 'Problem Solving', icon: BrainCircuit, description: 'Analytical thinker with creative solutions' },
]

export default function Skills() {
  return (
    <section id="skills" className="py-24 bg-gray-50">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold mb-16 text-center text-gray-800">Skills & Expertise</h2>
        <div className="grid md:grid-cols-2 gap-16">
          <div>
            <h3 className="text-2xl font-semibold mb-8 text-center text-blue-600">Technical Skills</h3>
            <div className="grid gap-8">
              {technicalSkills.map((skill) => (
                <div key={skill.name} className="flex items-center bg-white p-6 rounded-lg shadow-md transition-all duration-300 hover:shadow-lg hover:scale-105">
                  <skill.icon className="h-12 w-12 text-blue-500 mr-6" />
                  <div>
                    <h4 className="text-lg font-semibold mb-2">{skill.name}</h4>
                    <p className="text-gray-600">{skill.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div>
            <h3 className="text-2xl font-semibold mb-8 text-center text-blue-600">Soft Skills</h3>
            <div className="grid gap-8">
              {softSkills.map((skill) => (
                <div key={skill.name} className="flex items-center bg-white p-6 rounded-lg shadow-md transition-all duration-300 hover:shadow-lg hover:scale-105">
                  <skill.icon className="h-12 w-12 text-blue-500 mr-6" />
                  <div>
                    <h4 className="text-lg font-semibold mb-2">{skill.name}</h4>
                    <p className="text-gray-600">{skill.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

