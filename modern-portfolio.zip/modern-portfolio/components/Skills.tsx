import { Code, Database, BarChart, FileSpreadsheet, MessageSquare, Clock, Users, BrainCircuit } from 'lucide-react'

const technicalSkills = [
  { name: 'Python', icon: Code, description: 'Data analysis, automation, and web development' },
  { name: 'SQL', icon: Database, description: 'Database management and complex querying' },
  { name: 'Power BI', icon: BarChart, description: 'Data visualization and business intelligence' },
  { name: 'MS Office', icon: FileSpreadsheet, description: 'Advanced Excel, Word, and PowerPoint' },
]

const softSkills = [
  { name: 'Communication', icon: MessageSquare, description: 'Excellent verbal and written communication skills' },
  { name: 'Fast Learner', icon: Clock, description: 'Quick to adapt and master new technologies and concepts' },
  { name: 'Team Work', icon: Users, description: 'Collaborative approach to problem-solving and project execution' },
  { name: 'Time Management', icon: BrainCircuit, description: 'Efficient prioritization and organization of tasks' },
]

export default function Skills() {
  return (
    <section id="skills" className="py-24 bg-black bg-opacity-80">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold mb-16 text-center text-accent-green">Skills & Expertise</h2>
        <div className="grid md:grid-cols-2 gap-16">
          <div>
            <h3 className="text-2xl font-semibold mb-8 text-center text-accent-blue">Technical Skills</h3>
            <div className="space-y-6">
              {technicalSkills.map((skill) => (
                <div key={skill.name} className="bg-gray-900 p-6 rounded-lg shadow-md border border-accent-green">
                  <div className="flex items-center mb-2">
                    <skill.icon className="h-8 w-8 text-accent-green mr-4" />
                    <h4 className="text-xl font-semibold text-white">{skill.name}</h4>
                  </div>
                  <p className="text-gray-300">{skill.description}</p>
                </div>
              ))}
            </div>
          </div>
          <div>
            <h3 className="text-2xl font-semibold mb-8 text-center text-accent-blue">Soft Skills</h3>
            <div className="space-y-6">
              {softSkills.map((skill) => (
                <div key={skill.name} className="bg-gray-900 p-6 rounded-lg shadow-md border border-accent-blue">
                  <div className="flex items-center mb-2">
                    <skill.icon className="h-8 w-8 text-accent-blue mr-4" />
                    <h4 className="text-xl font-semibold text-white">{skill.name}</h4>
                  </div>
                  <p className="text-gray-300">{skill.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

