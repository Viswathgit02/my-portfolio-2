import { Code, Database, BarChart, FileSpreadsheet, MessageSquare, Clock, Users } from 'lucide-react'

const technicalSkills = [
  { name: 'Python', icon: Code },
  { name: 'SQL', icon: Database },
  { name: 'Power BI', icon: BarChart },
  { name: 'MS Office', icon: FileSpreadsheet },
]

const softSkills = [
  { name: 'Communication', icon: MessageSquare },
  { name: 'Fast Learner', icon: Clock },
  { name: 'Team Work', icon: Users },
]

export default function Skills() {
  return (
    <section id="skills" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold mb-8 text-center">Skills</h2>
        <div className="mb-12">
          <h3 className="text-2xl font-semibold mb-4">Technical Skills</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {technicalSkills.map((skill) => (
              <div key={skill.name} className="flex flex-col items-center">
                <skill.icon className="h-16 w-16 text-blue-500 mb-4" />
                <h4 className="text-xl font-semibold">{skill.name}</h4>
              </div>
            ))}
          </div>
        </div>
        <div>
          <h3 className="text-2xl font-semibold mb-4">Soft Skills</h3>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-8">
            {softSkills.map((skill) => (
              <div key={skill.name} className="flex flex-col items-center">
                <skill.icon className="h-16 w-16 text-blue-500 mb-4" />
                <h4 className="text-xl font-semibold">{skill.name}</h4>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

