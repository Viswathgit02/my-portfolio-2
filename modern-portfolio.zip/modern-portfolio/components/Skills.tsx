import { Code, Database, BarChart, FileSpreadsheet, MessageSquare, Clock, Users, BrainCircuit } from 'lucide-react'

const technicalSkills = [
  { name: 'Python', icon: Code, description: 'Data analysis, automation, and web development' },
  { name: 'SQL', icon: Database, description: 'Database management and complex querying' },
  { name: 'Power BI', icon: BarChart, description: 'Data visualization and business intelligence' },
  { name: 'MS Office', icon: FileSpreadsheet, description: 'Advanced Excel, Word, and PowerPoint' },
]

const softSkills = [
  { name: 'Communication', icon: MessageSquare },
  { name: 'Fast Learner', icon: Clock },
  { name: 'Team Work', icon: Users },
  { name: 'Time Management', icon: Clock },
]

export default function Skills() {
  return (
    <section id="skills" className="py-24 bg-gray-50">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold mb-16 text-center text-gray-800">Skills & Expertise</h2>
        <div className="grid md:grid-cols-2 gap-16">
          <div>
            <h3 className="text-2xl font-semibold mb-8 text-center text-blue-600">Technical Skills</h3>
            <div className="space-y-6">
              {technicalSkills.map((skill) => (
                <div key={skill.name} className="bg-white p-6 rounded-lg shadow-md">
                  <div className="flex items-center mb-2">
                    <skill.icon className="h-8 w-8 text-blue-500 mr-4" />
                    <h4 className="text-xl font-semibold">{skill.name}</h4>
                  </div>
                  <p className="text-gray-600">{skill.description}</p>
                </div>
              ))}
            </div>
          </div>
          <div>
            <h3 className="text-2xl font-semibold mb-8 text-center text-blue-600">Soft Skills</h3>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <ul className="grid grid-cols-2 gap-4">
                {softSkills.map((skill, index) => (
                  <li key={index} className="flex items-center">
                    <skill.icon className="h-6 w-6 text-blue-500 mr-2" />
                    <span>{skill.name}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

