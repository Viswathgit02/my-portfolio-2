import { Code, Database, BarChart, FileSpreadsheet } from 'lucide-react'

const skills = [
  { name: 'Python', icon: Code },
  { name: 'SQL', icon: Database },
  { name: 'Power BI', icon: BarChart },
  { name: 'MS Office', icon: FileSpreadsheet },
]

export default function Skills() {
  return (
    <section id="skills" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold mb-8 text-center">Technical Skills</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {skills.map((skill) => (
            <div key={skill.name} className="flex flex-col items-center">
              <skill.icon className="h-16 w-16 text-blue-500 mb-4" />
              <h3 className="text-xl font-semibold">{skill.name}</h3>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

