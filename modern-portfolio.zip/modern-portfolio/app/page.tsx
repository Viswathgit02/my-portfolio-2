import Header from '../components/Header'
import Hero from '../components/Hero'
import Skills from '../components/Skills'
import Experience from '../components/Experience'
import Education from '../components/Education'
import Certifications from '../components/Certifications'
import Footer from '../components/Footer'

export default function Home() {
  return (
    <main className="relative">
      <div className="absolute inset-0 bg-[url('/grid.svg')] bg-center [mask-image:linear-gradient(180deg,white,rgba(255,255,255,0))]"></div>
      <div className="relative z-10">
        <Header />
        <Hero />
        <Skills />
        <Experience />
        <Education />
        <Certifications />
        <Footer />
      </div>
    </main>
  )
}

