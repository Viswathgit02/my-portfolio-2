import Header from '../components/Header'
import Hero from '../components/Hero'
import Skills from '../components/Skills'
import Experience from '../components/Experience'
import Education from '../components/Education'
import Certifications from '../components/Certifications'
import Footer from '../components/Footer'

export default function Home() {
  return (
    <main className="relative bg-black bg-opacity-80 min-h-screen">
      <Header />
      <Hero />
      <Skills />
      <Experience />
      <Education />
      <Certifications />
      <Footer />
    </main>
  )
}

