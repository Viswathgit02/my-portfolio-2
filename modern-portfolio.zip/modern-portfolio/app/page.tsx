import Header from '../components/Header'
import Hero from '../components/Hero'
import Skills from '../components/Skills'
import Experience from '../components/Experience'
import Education from '../components/Education'
import Footer from '../components/Footer'

export default function Home() {
  return (
    <main className="min-h-screen bg-gray-100">
      <Header />
      <Hero />
      <Skills />
      <Experience />
      <Education />
      <Footer />
    </main>
  )
}

